import express from "express";
import ViteExpress from "vite-express";
import Database from "better-sqlite3";

const app = express();
const db = new Database("songs.db");

app.use(express.json());

app.get("/songs/artist/:artist", (req, res) => {
    const stmt = db.prepare("SELECT * FROM wadsongs WHERE artist = ?");
    const rows = stmt.all(req.params.artist);
    res.json(rows);
});

ViteExpress.listen(app, 3000, () =>
    console.log("Server + Vite is running on http://localhost:3000")
)