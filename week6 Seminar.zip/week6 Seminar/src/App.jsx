import React, { useState } from "react";

function App() {
    const [artist, setArtist] = useState("");
    const [results, setResults] = useState([]);

    function updateArtist(e) {
        setArtist(e.target.value)
    }

    async function searchSongs() {
        if(artist.trim() === ""){
            alert("Please enter artist name");
            return;
        }

        try{
            const response = await fetch(`/songs/artist/${artist}`);
            const data = await response.json();

            setResults(data);
        } catch (error) {
            console.error(error);
            alert("Error Searching Songs")
        }

    }

    return (
        <div>
        <h1>Hittastic React Search</h1>

        <input
            type="text"
            placeholder="Enter Artist Name"
            value={artist}
            onChange={updateArtist} />

        <button onClick={searchSongs}>Search</button>

        <div>
            <h3>Current Artist is : {artist}</h3>
        </div>
        <hr />

        <h2> Search Results</h2>

        {results.length === 0 ? (
            <p>No results yet</p>
        ) : (
            <ul>
                {results.map((song) => (
                    <li key={song.id}>
                        <b>{song.title}</b> by {song.artist} (£{song.price})
                    </li>
                ))}
            </ul>
        )}
        </div>
    );
}
export default App;