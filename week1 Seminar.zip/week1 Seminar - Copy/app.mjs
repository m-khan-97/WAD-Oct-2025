import express from 'express';
import Database from 'better-sqlite3';
const app = express();
const db = new Database('songs.db');

app.get('/', (req, res) => res.send('Hello World'));
app.get('/time', (req, res) => res.send(`Server time: ${Date.now()}`));
app.get('/greet/:name', (req, res) => res.send(`Hello ${req.params.name}`))

app.get('/songs/artist/:artist', (req, res) => {
    const stmt = db.prepare('SELECT * FROM wadsongs WHERE artist = ?');
    const rows = stmt.all(req.params.artist);
    res.json(rows);
});z

app.get('/songs/search/:artist/:title', (req, res) => {
    const stmt = db.prepare('SELECT * FROM wadsongs WHERE artist = ? AND title = ?');
    const rows = stmt.all(req.params.artist, req.params.title);
    res.json(rows);
});


app.use(express.json());
app.listen(3000, () => console.log('Server is running on http://localhost3000'));