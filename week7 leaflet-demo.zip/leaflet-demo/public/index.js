import "leaflet";
import "./style.css";

const map = L.map("map1");

const attrib="Map data copyright OpenStreetMap contributors, Open Database Licence";

L.tileLayer
        ("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            { attribution: attrib } 
).addTo(map);

const position = [51.5085, -0.12574];
map.setView(position, 16);

const marker = L.marker(position).addTo(map);
marker.bindPopup("<b>London</b><br>Welcome to London");

map.on("click", e => {
    alert(`You clicked at :\nLat: ${e.latlng.lat}\nLng: ${e.latlng.lng}`)
});

// map.on("mousemove", e => {
//     alert(`Mouse at : ${e.latlng.lat}, ${e.latlng.lng}`);
// });