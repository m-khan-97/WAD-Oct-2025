// routes/users.mjs
import express from "express";
import db from "../db.mjs";
import UsersController from "../controllers/UsersController.mjs";

const usersRouter = express.Router();
const controller = new UsersController(db);

usersRouter.post("/login", controller.login.bind(controller));
usersRouter.post("/logout", controller.logout.bind(controller));
usersRouter.get("/login", controller.currentUser.bind(controller));

export default usersRouter;
