// routes/songs.mjs
import express from "express";
import db from "../db.mjs";
import SongsController from "../controllers/SongsController.mjs";

const songsRouter = express.Router();
const controller = new SongsController(db);

// GET (public)
songsRouter.get("/artist/:artist", controller.getByArtist.bind(controller));
songsRouter.get(
  "/search/:artist/:title",
  controller.getByArtistAndTitle.bind(controller)
);

// POST/PUT/DELETE (protected by authRequired middleware in server.mjs)
songsRouter.post("/", controller.addSong.bind(controller));
songsRouter.put("/:id", controller.updateSong.bind(controller));
songsRouter.delete("/:id", controller.deleteSong.bind(controller));
songsRouter.post("/buy/:id", controller.buySong.bind(controller));

export default songsRouter;
