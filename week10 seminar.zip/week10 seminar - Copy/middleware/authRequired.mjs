// middleware/authRequired.mjs
export default function authRequired(req, res, next) {
  // Allow all GET requests without login
  if (req.method === "GET") return next();

  // For POST/PUT/DELETE require login
  if (req.session?.username) return next();

  return res.status(401).json({ error: "You're not logged in." });
}
