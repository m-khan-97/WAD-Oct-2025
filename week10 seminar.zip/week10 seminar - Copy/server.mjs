// server.mjs
import express from "express";
import session from "express-session";
import betterExpressStore from "better-express-store";
import "dotenv/config";

import songsRouter from "./routes/songs.mjs";
import usersRouter from "./routes/users.mjs";
import authRequired from "./middleware/authRequired.mjs";

const app = express();
app.use(express.json());

// Sessions (stored in SQLite via better-express-store)
app.use(
  session({
    secret: process.env.SESSION_SECRET || "dev-secret",
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: { maxAge: 600000 }, // 10 mins inactivity
    store: betterExpressStore({
      dbPath: process.env.SESSION_DB || "session.db",
      tableName: "sessions",
    }),
  })
);

// Routes
app.use("/users", usersRouter);

app.use("/songs", authRequired, songsRouter);

app.get("/", (req, res) => res.send("API is running"));

app.listen(3000, () => console.log("http://localhost:3000"));
