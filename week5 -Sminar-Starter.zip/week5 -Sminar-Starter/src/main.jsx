import React from "react";
import ReactDOM from "react-dom/client"
import Greeting from "./components/Greeting";
import InterectiveGreeting from "./components/InterectiveGreeting";

const rootElement = document.getElementById('root')
const root = ReactDOM.createRoot(rootElement)

root.render(
<div>
<h1>Hello World from React!!</h1>
<Greeting firstname="John" lastname="Brown"/>
<Greeting firstname="Muhammad" lastname="Ibrahim"/>
<InterectiveGreeting />

</div>
)