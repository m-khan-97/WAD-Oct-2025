import React from "react";

function Greeting({firstname, lastname}) {
    return <h2>Hello {firstname} {lastname}</h2>
}

export default Greeting