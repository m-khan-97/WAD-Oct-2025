import React from "react";
import { useState } from "react";


function InterectiveGreeting() {
    const [name, setName] = useState('No Name')

    function handleChange(e) {
        setName(e.target.value)
    }

    return (
        <div>
            <h2>Enter your name</h2>
            <input type="text" value={name} onChange={handleChange} />
            <div>Hello {name}</div>
        </div>
    )
}

export default InterectiveGreeting