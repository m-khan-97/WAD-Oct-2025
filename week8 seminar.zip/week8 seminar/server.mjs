import express from "express";
import Database from "better-sqlite3";
import session from "express-session";
import SQLiteStoreFactory from "better-sqlite3-session-store";

const app = express();
app.use(express.json());
app.use(express.static("public"));


// Main app database (songs, users)
const db = new Database("songs.db");

// Session database (SEPARATE)
const sessionDb = new Database("session.db");


// Create the store factory FIRST
const SQLiteStore = SQLiteStoreFactory(session);

// Then create the store with the database
const sessionStore = new SQLiteStore({
  client: sessionDb
});


app.use(
  session({
    store: sessionStore,
    secret: "VerySecretKey",
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: { maxAge: 600000 }
  })
);

app.post("/login", (req, res) => {
  const {username, password} = req.body;

  const stmt = db.prepare("SELECT * FROM ht_users WHERE username=? AND password=?");
  const results = stmt.all(username, password);

  if(results.length === 1) {
    req.session.username = username;
    res.json({username});
  } else {
    res.status(401).json({error: "Incorrect Login"});
  }
});

app.get("/login", (req, res) => {
  res.json({username: req.session.username || null})
});

app.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({success: true});
  });
});

// Middleware

function mustBeLoggedIn(req, res, next) {
  if(!req.session.username) {
    return res.status(401).json({error: "Not Logged in"})
  }
  next();
}

app.get("/songs/artist/:artist", (req, res) => {
  const stmt = db.prepare("SELECT * FROM wadsongs WHERE artist=?");
  res.json(stmt.all(req.params.artist));
});

app.post("/songs/buy/:id", mustBeLoggedIn, (req, res) => {
  const stmt = db.prepare(
    "UPDATE wadsongs SET quantity = quantity - 1 WHERE id=? AND quantity > 0"
  );

  const info = stmt.run(req.params.id);

  if (info.changes === 1) {
    res.json({ message: "Song purchased successfully!" });
  } else {
    res.status(400).json({ error: "Out of stock" });
  }
});


app.listen(3000, () =>
  console.log("✅ Server running on http://localhost:3000")
);
