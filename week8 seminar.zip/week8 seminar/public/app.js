document.getElementById("searchBtn").addEventListener("click", async () => {
  const artist = document.getElementById("artist").value;
  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = "";

  const response = await fetch(`/songs/artist/${artist}`);
  const songs = await response.json();

  songs.forEach(song => {
    const p = document.createElement("p");
    p.innerHTML = `${song.title} (£${song.price})`;

    const btn = document.createElement("button");
    btn.textContent = "Buy";

    btn.addEventListener("click", async () => {
      const res = await fetch(`/songs/buy/${song.id}`, { method: "POST" });
      const data = await res.json();
      alert(data.message || data.error);
    });

    p.appendChild(btn);
    resultsDiv.appendChild(p);
  });
});

const status = document.getElementById("status");
const loginBox = document.getElementById("loginBox");
const logoutBtn = document.getElementById("logoutBtn");

document.getElementById("loginBtn").addEventListener("click", async () => {
  const username = document.getElementById("user").value;
  const password = document.getElementById("pass").value;

  const res = await fetch("/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({username, password})
  });

  if(res.status === 200) {
    const data = await res.json();
    status.textContent = `Logged in as ${data.username}`;
    loginBox.style.display = "none";
    logoutBtn.style.display = "inline"
  } else {
    alert("Login Failed");
  }
});

logoutBtn.addEventListener("click", async () => {
  await fetch("/logout", {method: "POST"});
  status.textContent = "";
  loginBox.style.display = "block";
  logoutBtn.style.display = "none"
});