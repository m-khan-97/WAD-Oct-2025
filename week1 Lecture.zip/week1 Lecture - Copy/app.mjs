import express from 'express';
import Database from 'better-sqlite3';
const app = express();
const db = new Database('students.db');

app.use(express.json());

app.get('/', (req,res) => {
    res.send('Welcome to Web Application Development!');
});

app.get('/time', (req,res) => {
    res.send(`Milliseconds since 1970 : ${Date.now()}`);
});

app.get('/students/:lastname', (req, res) => {
    try{
        const stmt = db.prepare("SELECT * FROM students WHERE lastname=?");
        const results = stmt.all(req.params.lastname);
        res.json(results);
    } catch (err) {
        res.status(500).json({error: err.message });
    }

});

app.post('students/create', (req, res) => {
    try{
        const stmt = db.prepare("INSERT INTO students(firstname,lastname, course) VALUES(?,?,?)");
        const info = stmt.run(req.body.firstname, req.body.lastname, req.body.course)
        res.json({id: info.lastInsertRowid});
    } catch (err) {
        res.status(500).json({error: err.message});
    }
})



app.listen(3000);
