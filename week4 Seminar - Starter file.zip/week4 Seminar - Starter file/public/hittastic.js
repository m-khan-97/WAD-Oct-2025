// hittastic.js

window.addEventListener('DOMContentLoaded', () => {
  const searchBtn = document.getElementById('searchBtn');
  const addBtn = document.getElementById('addBtn');


  if (searchBtn) {
    searchBtn.addEventListener('click', async () => {
      const artist = document.getElementById('artist').value.trim();
      const resultsDiv = document.getElementById('results');

      if (artist === "") {
        resultsDiv.innerHTML = "<p style='color:red;'>Please enter an artist name!</p>";
        return;
      }

      try {
        const response = await fetch(`/songs/artist/${artist}`);
        const songs = await response.json();

        if (songs.length === 0) {
          resultsDiv.innerHTML = "<p>No songs found.</p>";
          return;
        }

        let html = "<h3>Results:</h3><ul>";
        songs.forEach(song => {
          html += `
            <li>
              <b>${song.title}</b> by ${song.artist} (£${song.price})
              <button onclick="buySong(${song.id})">Buy</button>
            </li>`;
        });
        html += "</ul>";
        resultsDiv.innerHTML = html;
      } catch (err) {
        resultsDiv.innerHTML = `<p style='color:red;'>Error: ${err.message}</p>`;
      }
    });
  }


  if (addBtn) {
    addBtn.addEventListener('click', async () => {
      const title = document.getElementById('title').value.trim();
      const artist = document.getElementById('artistName').value.trim();
      const price = document.getElementById('price').value.trim();
      const quantity = document.getElementById('quantity').value.trim();
      const msg = document.getElementById('message');

      if (!title || !artist || !price || !quantity) {
        msg.style.color = 'red';
        msg.textContent = 'Please fill in all fields!';
        return;
      }

      try {
        const response = await fetch('/songs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title, artist, price, quantity })
        });

        const result = await response.json();

        if (!response.ok) {
          msg.style.color = 'red';
          msg.textContent = `Error: ${result.error}`;
        } else {
          msg.style.color = 'green';
          msg.textContent = result.message;
        }
      } catch (err) {
        msg.style.color = 'red';
        msg.textContent = `Error: ${err.message}`;
      }
    });
  }
});


async function buySong(id) {
  const response = await fetch(`/songs/buy/${id}`, { method: 'POST' });
  const result = await response.json();

  if (response.ok) {
    alert(result.message);
  } else {
    alert(`Error: ${result.error}`);
  }
}
