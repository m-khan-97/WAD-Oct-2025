import express from 'express';
import Database from 'better-sqlite3';
const app = express();
const db = new Database('songs.db');

app.use(express.json());
app.use(express.static('public'));

app.get('/songs/artist/:artist', (req, res) => {
    const stmt = db.prepare('SELECT * FROM wadsongs WHERE artist = ?');
    const rows = stmt.all(req.params.artist);
    res.json(rows);
});

app.get('/songs/search/:artist/:title', (req, res) => {
    const stmt = db.prepare('SELECT * FROM wadsongs WHERE artist = ? AND title = ?');
    const rows = stmt.all(req.params.artist, req.params.title);
    res.json(rows);
});

app.post('/songs', (req, res) => {
    try{
        const stmt = db.prepare("INSERT INTO wadsongs (title, artist, price, quantity) VALUES (?, ?, ?, ?)");
        const info = stmt.run(req.body.title, req.body.artist, req.body.price, req.body.quantity);
        res.status(201).json({message: '✅ Song added successfully!', id: info.lastInsertRowid});
    } catch (error) {
        res.status(500).json({error:error.message});
    }
});  
      

app.put('/songs/:id', (req, res) => {
    try{
        const stmt = db.prepare("UPDATE wadsongs SET price=?, quantity=? WHERE id=?");
        const info = stmt.run(req.body.price, req.body.quantity,req.params.id );

        if(info.changes === 1) {
            res.status(200).json({ success: true});
        } else {
            res.status(404).json({error: "Song not found"});
        } 
    } catch (error) {
        res.status(500).json({error:error.message});
    }
});

app.delete('/songs/:id', (req, res) => {
    try{
        const stmt = db.prepare("DELETE FROM wadsongs WHERE id=?");
        const info = stmt.run(req.params.id);

        if(info.changes === 1) {
            res.json({success: true});
        } else {
            res.status(404).json({error: "No song found with that ID"});
        }
    } catch (error) {
        res.status(500).json({error: error.message});
    }
});

app.post('/songs/buy/:id', (req, res) => {
    try{
        const stmt = db.prepare("UPDATE wadsongs SET quantity = quantity - 1 WHERE id=? AND quantity > 0");
        const info = stmt.run(req.params.id);

        if (info.changes === 1) {
            const orderstmt = db.prepare("INSERT INTO orders (song_id, quantity) VALUES (?, 1)");
            orderstmt.run(req.params.id);
            res.status(200).json({message: "Song purchased successfully"});
        } else {
            res.status(400).json({error: "Out of stock or invalid ID"});
        }
    } catch (error){
        res.status(500).json({error: error.message});
    }
})


app.use(express.json());
app.listen(3000, () => console.log('Server is running on http://localhost3000'));