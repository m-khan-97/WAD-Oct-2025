document.getElementById("searchBtn").addEventListener("click", async () => {
  const artist = document.getElementById("artist").value;
  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = "";

  const response = await fetch(`/songs/artist/${artist}`);
  const songs = await response.json();

  songs.forEach(song => {
    const p = document.createElement("p");
    p.innerHTML = `${song.title} (£${song.price})`;

    const btn = document.createElement("button");
    btn.textContent = "Buy";

    btn.addEventListener("click", async () => {
      const res = await fetch(`/songs/buy/${song.id}`, { method: "POST" });
      const data = await res.json();
      alert(data.message || data.error);
    });

    p.appendChild(btn);
    resultsDiv.appendChild(p);
  });
});
